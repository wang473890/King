package main

import (
	"king"
)

func main() {
	king.Main()
}
